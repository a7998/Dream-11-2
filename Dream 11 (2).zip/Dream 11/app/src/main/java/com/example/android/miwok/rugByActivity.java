package com.example.android.miwok;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class rugByActivity extends
 AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colors);
ArrayList<Word> rugby= new ArrayList<Word>();
        
        rugby.add(new Word(R.drawable.chelseaflag,"vs",R.drawable.manchesterflag,"4","H"));
rugby.add(new Word(R.drawable.indiaflag,"vs",R.drawable.Africa,"4","H"));
rugby.add(new Word(R.drawable.austrailiaflag,"vs",R.drawable.japanflag,"4","H"));
rugby.add(new Word(R.drawable.spainflag,"vs",R.drawable.,"4","H"));
rugby.add(new Word(R.drawable.bazilflag,"vs",R.drawable.franceflag,"4","H"));

        

}

}